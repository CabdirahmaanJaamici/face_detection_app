"use client";

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function TamarCalculator() {
  const [display, setDisplay] = useState("0");
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForOperand, setWaitingForOperand] = useState(false);
  const [memory, setMemory] = useState(0);
  const [isCalculating, setIsCalculating] = useState(false);
  const { toast } = useToast();

  // Keyboard support
  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      event.preventDefault();
      
      if (event.key >= '0' && event.key <= '9') {
        inputNumber(event.key);
      } else if (event.key === '.') {
        inputDecimal();
      } else if (event.key === '+' || event.key === '-' || event.key === '*' || event.key === '/') {
        const op = event.key === '*' ? '×' : event.key === '/' ? '÷' : event.key;
        performOperation(op);
      } else if (event.key === 'Enter' || event.key === '=') {
        calculate();
      } else if (event.key === 'Escape') {
        clear();
      } else if (event.key === 'Backspace') {
        backspace();
      } else if (event.key === '%') {
        percentage();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [display, previousValue, operation, waitingForOperand]);

  const inputNumber = (num: string) => {
    if (waitingForOperand) {
      setDisplay(num);
      setWaitingForOperand(false);
    } else {
      setDisplay(display === "0" ? num : display + num);
    }
  };

  const inputDecimal = () => {
    if (waitingForOperand) {
      setDisplay("0.");
      setWaitingForOperand(false);
    } else if (display.indexOf(".") === -1) {
      setDisplay(display + ".");
    }
  };

  const clear = () => {
    setDisplay("0");
    setPreviousValue(null);
    setOperation(null);
    setWaitingForOperand(false);
  };

  const clearEntry = () => {
    setDisplay("0");
  };

  const backspace = () => {
    if (display.length > 1) {
      setDisplay(display.slice(0, -1));
    } else {
      setDisplay("0");
    }
  };

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);

    if (previousValue === null) {
      setPreviousValue(inputValue);
    } else if (operation) {
      const currentValue = previousValue;
      let newValue: number;

      switch (operation) {
        case "+":
          newValue = currentValue + inputValue;
          break;
        case "-":
          newValue = currentValue - inputValue;
          break;
        case "×":
          newValue = currentValue * inputValue;
          break;
        case "÷":
          if (inputValue === 0) {
            toast({
              title: "Error",
              description: "Cannot divide by zero",
              variant: "destructive",
            });
            return;
          }
          newValue = currentValue / inputValue;
          break;
        default:
          newValue = inputValue;
      }

      setPreviousValue(newValue);
      setDisplay(String(newValue));
    }

    setWaitingForOperand(true);
    setOperation(nextOperation);
  };

  const calculate = () => {
    const inputValue = parseFloat(display);

    if (previousValue !== null && operation) {
      setIsCalculating(true);
      
      setTimeout(() => {
        let newValue: number;

        switch (operation) {
          case "+":
            newValue = previousValue + inputValue;
            break;
          case "-":
            newValue = previousValue - inputValue;
            break;
          case "×":
            newValue = previousValue * inputValue;
            break;
          case "÷":
            if (inputValue === 0) {
              toast({
                title: "Error",
                description: "Cannot divide by zero",
                variant: "destructive",
              });
              setIsCalculating(false);
              return;
            }
            newValue = previousValue / inputValue;
            break;
          default:
            newValue = inputValue;
        }

        // Format the result to avoid long decimal numbers
        const formattedResult = Number(newValue.toFixed(10));
        setDisplay(String(formattedResult));
        setPreviousValue(null);
        setOperation(null);
        setWaitingForOperand(true);
        setIsCalculating(false);
      }, 300);
    }
  };

  const percentage = () => {
    const value = parseFloat(display);
    setDisplay(String(value / 100));
  };

  const squareRoot = () => {
    const value = parseFloat(display);
    if (value < 0) {
      toast({
        title: "Error",
        description: "Cannot calculate square root of negative number",
        variant: "destructive",
      });
      return;
    }
    const result = Math.sqrt(value);
    setDisplay(String(Number(result.toFixed(10))));
    setWaitingForOperand(true);
  };

  const toggleSign = () => {
    const value = parseFloat(display);
    setDisplay(String(-value));
  };

  const reciprocal = () => {
    const value = parseFloat(display);
    if (value === 0) {
      toast({
        title: "Error",
        description: "Cannot divide by zero",
        variant: "destructive",
      });
      return;
    }
    const result = 1 / value;
    setDisplay(String(Number(result.toFixed(10))));
    setWaitingForOperand(true);
  };

  const memoryAdd = () => {
    setMemory(memory + parseFloat(display));
    toast({
      title: "Memory",
      description: `Added to memory: ${display}`,
    });
  };

  const memorySubtract = () => {
    setMemory(memory - parseFloat(display));
    toast({
      title: "Memory",
      description: `Subtracted from memory: ${display}`,
    });
  };

  const memoryRecall = () => {
    setDisplay(String(memory));
  };

  const memoryClear = () => {
    setMemory(0);
    toast({
      title: "Memory",
      description: "Memory cleared",
    });
  };

  const CalculatorButton = ({ 
    onClick, 
    children, 
    variant = "outline", 
    className = "",
    disabled = false 
  }: {
    onClick: () => void;
    children: React.ReactNode;
    variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
    className?: string;
    disabled?: boolean;
  }) => (
    <Button
      onClick={onClick}
      variant={variant}
      className={`h-16 text-lg font-semibold transition-all duration-200 hover:scale-105 active:scale-95 ${className}`}
      disabled={disabled}
    >
      {children}
    </Button>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-blue-100 to-cyan-100 dark:from-blue-900 dark:via-blue-800 dark:to-cyan-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md space-y-6">
        {/* Animated Logo and Title */}
        <div className="text-center space-y-2 animate-fade-in">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-blue-400 rounded-full blur-xl opacity-30 animate-pulse"></div>
            <div className="relative bg-gradient-to-r from-blue-500 to-cyan-500 text-white px-8 py-4 rounded-2xl shadow-2xl transform hover:scale-105 transition-transform duration-300">
              <h1 className="text-4xl font-bold tracking-wide">
                Tamar <span className="text-cyan-200">Calculator</span>
              </h1>
            </div>
          </div>
          <Badge variant="secondary" className="text-sm bg-blue-200 text-blue-800 dark:bg-blue-700 dark:text-blue-100 animate-bounce-slow">
            Advanced Scientific Calculator
          </Badge>
        </div>

        {/* Calculator Card with Animation */}
        <Card className="shadow-2xl border-2 border-blue-200 dark:border-blue-700 transform hover:scale-[1.02] transition-all duration-300 animate-slide-up">
          <CardHeader className="pb-4 bg-gradient-to-r from-blue-500/10 to-cyan-500/10 rounded-t-xl">
            <CardTitle className="sr-only">Calculator Display</CardTitle>
            <div className="space-y-2">
              <div className="text-right text-sm text-blue-600 dark:text-blue-300 h-6 font-medium">
                {previousValue !== null && operation && (
                  <span className="animate-pulse">
                    {previousValue} {operation}
                  </span>
                )}
              </div>
              <div className="relative">
                <div className={`absolute inset-0 bg-blue-200 dark:bg-blue-800 rounded-lg transition-all duration-300 ${isCalculating ? 'opacity-100 scale-105' : 'opacity-0 scale-95'}`}></div>
                <Input
                  value={display}
                  readOnly
                  className={`text-right text-3xl font-mono font-bold h-16 bg-white dark:bg-blue-900 border-2 border-blue-200 dark:border-blue-700 text-blue-900 dark:text-blue-100 transition-all duration-300 ${isCalculating ? 'scale-105' : ''}`}
                />
              </div>
              <div className="text-right text-xs text-blue-500 dark:text-blue-300 font-medium">
                {memory !== 0 && `M: ${memory}`}
              </div>
            </div>
          </CardHeader>
          
          <CardContent className="space-y-2 p-4 bg-gradient-to-b from-white to-blue-50 dark:from-blue-900 dark:to-blue-950">
            {/* Memory Row */}
            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '100ms'}}>
              <CalculatorButton onClick={memoryClear} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                MC
              </CalculatorButton>
              <CalculatorButton onClick={memoryRecall} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                MR
              </CalculatorButton>
              <CalculatorButton onClick={memoryAdd} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                M+
              </CalculatorButton>
              <CalculatorButton onClick={memorySubtract} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                M-
              </CalculatorButton>
              <CalculatorButton onClick={clear} variant="destructive" className="bg-red-500 hover:bg-red-600 text-white">
                C
              </CalculatorButton>
            </div>

            {/* Advanced Functions Row */}
            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '200ms'}}>
              <CalculatorButton onClick={squareRoot} variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white">
                √
              </CalculatorButton>
              <CalculatorButton onClick={reciprocal} variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white">
                1/x
              </CalculatorButton>
              <CalculatorButton onClick={percentage} variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white">
                %
              </CalculatorButton>
              <CalculatorButton onClick={toggleSign} variant="secondary" className="bg-blue-500 hover:bg-blue-600 text-white">
                +/-
              </CalculatorButton>
              <CalculatorButton onClick={backspace} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                ⌫
              </CalculatorButton>
            </div>

            {/* Number Pad */}
            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '300ms'}}>
              <CalculatorButton onClick={() => inputNumber("7")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                7
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("8")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                8
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("9")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                9
              </CalculatorButton>
              <CalculatorButton onClick={() => performOperation("÷")} variant="default" className="bg-cyan-500 hover:bg-cyan-600 text-white">
                ÷
              </CalculatorButton>
              <CalculatorButton onClick={clearEntry} variant="outline" className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                CE
              </CalculatorButton>
            </div>

            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '400ms'}}>
              <CalculatorButton onClick={() => inputNumber("4")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                4
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("5")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                5
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("6")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                6
              </CalculatorButton>
              <CalculatorButton onClick={() => performOperation("×")} variant="default" className="bg-cyan-500 hover:bg-cyan-600 text-white">
                ×
              </CalculatorButton>
              <CalculatorButton onClick={() => performOperation("-")} variant="default" className="bg-cyan-500 hover:bg-cyan-600 text-white">
                -
              </CalculatorButton>
            </div>

            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '500ms'}}>
              <CalculatorButton onClick={() => inputNumber("1")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                1
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("2")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                2
              </CalculatorButton>
              <CalculatorButton onClick={() => inputNumber("3")} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                3
              </CalculatorButton>
              <CalculatorButton onClick={() => performOperation("+")} variant="default" className="bg-cyan-500 hover:bg-cyan-600 text-white">
                +
              </CalculatorButton>
              <CalculatorButton 
                onClick={calculate} 
                variant="default" 
                className={`row-span-2 h-32 bg-gradient-to-b from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-lg ${isCalculating ? 'animate-pulse' : ''}`}
              >
                =
              </CalculatorButton>
            </div>

            <div className="grid grid-cols-5 gap-2 animate-fade-in" style={{animationDelay: '600ms'}}>
              <CalculatorButton onClick={() => inputNumber("0")} className="col-span-2 border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                0
              </CalculatorButton>
              <CalculatorButton onClick={inputDecimal} className="border-blue-200 dark:border-blue-700 hover:bg-blue-100 dark:hover:bg-blue-800">
                .
              </CalculatorButton>
            </div>
          </CardContent>
        </Card>

        {/* Footer with animation */}
        <div className="text-center text-sm text-blue-600 dark:text-blue-300 space-y-1 animate-fade-in" style={{animationDelay: '700ms'}}>
          <p className="font-medium">Supports basic arithmetic, memory functions, and advanced operations</p>
          <p className="text-xs opacity-75">Try: 123 + 456 = 579 or √16 = 4</p>
        </div>
      </div>

      <style jsx global>{`
        @keyframes fade-in {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes slide-up {
          from {
            opacity: 0;
            transform: translateY(40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes bounce-slow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-5px);
          }
        }
        
        .animate-fade-in {
          animation: fade-in 0.6s ease-out forwards;
          opacity: 0;
        }
        
        .animate-slide-up {
          animation: slide-up 0.8s ease-out forwards;
          opacity: 0;
        }
        
        .animate-bounce-slow {
          animation: bounce-slow 3s ease-in-out infinite;
        }
      `}</style>
    </div>
  );
}