import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Tamar Calculator - Advanced Scientific Calculator",
  description: "A modern, feature-rich calculator with memory functions, advanced operations, and responsive design. Built with Next.js, TypeScript, and Tailwind CSS.",
  keywords: ["calculator", "scientific calculator", "Tamar calculator", "math", "arithmetic", "Next.js", "TypeScript", "Tailwind CSS"],
  authors: [{ name: "Tamar Calculator Team" }],
  openGraph: {
    title: "Tamar Calculator",
    description: "Advanced scientific calculator with modern UI and comprehensive features",
    url: "https://chat.z.ai",
    siteName: "Tamar Calculator",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Tamar Calculator",
    description: "Advanced scientific calculator with modern UI and comprehensive features",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
