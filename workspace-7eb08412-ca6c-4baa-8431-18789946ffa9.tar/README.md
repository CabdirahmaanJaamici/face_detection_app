# 🧮 Tamar Calculator

A modern, feature-rich calculator application built with Next.js 15, TypeScript, and Tailwind CSS. Featuring a beautiful blue light theme, smooth animations, and comprehensive calculation capabilities.

## ✨ Features

### 🎯 Core Calculator Functions
- **Basic Arithmetic**: Addition (+), Subtraction (-), Multiplication (×), Division (÷)
- **Advanced Operations**: Square root (√), Reciprocal (1/x), Percentage (%), Sign toggle (+/-)
- **Memory Functions**: Memory Clear (MC), Memory Recall (MR), Memory Add (M+), Memory Subtract (M-)
- **Clear Functions**: Full Clear (C), Clear Entry (CE), Backspace (⌫)

### ⌨️ Full Keyboard Support
- **Numbers**: 0-9 keys
- **Operations**: +, -, *, / (mapped to × and ÷)
- **Actions**: Enter or = for calculation, Escape for clear, Backspace for deletion, % for percentage

### 🎨 Modern UI/UX Design
- **Blue Light Theme**: Beautiful gradient from blue to cyan
- **Smooth Animations**: Fade-in, slide-up, hover effects, and calculation feedback
- **Responsive Design**: Works perfectly on mobile and desktop
- **Dark Mode Support**: Complete dark mode compatibility
- **Visual Feedback**: Loading states, hover effects, and operation previews

### 🚀 Technical Stack
- **⚡ Next.js 15** - React framework with App Router
- **📘 TypeScript 5** - Type-safe development
- **🎨 Tailwind CSS 4** - Utility-first CSS framework
- **🧩 shadcn/ui** - High-quality UI components
- **🌈 Framer Motion** - Smooth animations
- **🎯 Lucide React** - Beautiful icons

## 🎯 Why Tamar Calculator?

- **🏎️ Fast & Responsive** - Instant calculations with smooth animations
- **🎨 Beautiful Design** - Modern blue light theme with professional aesthetics
- **📱 Mobile-Friendly** - Perfect responsive design for all devices
- **⌨️ Keyboard Support** - Full keyboard navigation for desktop users
- **🧠 Smart Features** - Memory functions, advanced operations, error handling
- **🌙 Dark Mode** - Complete dark mode support
- **🚀 Production Ready** - Optimized build and deployment settings

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start
```

Open [http://localhost:3000](http://localhost:3000) to see the Tamar Calculator in action.

## 🎮 How to Use

### Basic Operations
1. **Number Input**: Click number buttons or use keyboard (0-9)
2. **Operations**: Click operation buttons (+, -, ×, ÷) or use keyboard (+, -, *, /)
3. **Calculation**: Press "=" button or Enter key
4. **Clear**: Use "C" for full clear or "CE" for clear entry

### Advanced Functions
- **Square Root**: Click "√" button
- **Reciprocal**: Click "1/x" button
- **Percentage**: Click "%" button
- **Sign Toggle**: Click "+/-" button

### Memory Functions
- **Memory Clear (MC)**: Clear memory
- **Memory Recall (MR)**: Recall stored value
- **Memory Add (M+)**: Add current value to memory
- **Memory Subtract (M-)**: Subtract current value from memory

### Keyboard Shortcuts
- **Numbers**: 0-9
- **Operations**: +, -, *, /
- **Equals**: Enter or =
- **Clear**: Escape
- **Backspace**: Backspace key
- **Decimal**: . key
- **Percentage**: % key

## 🎨 Design Features

### Animations
- **Fade-in Effects**: Smooth appearance of UI elements
- **Hover Animations**: Buttons scale on hover (105%) and compress on click (95%)
- **Calculation Feedback**: Visual feedback during calculations
- **Staggered Loading**: Buttons appear in sequence for smooth loading

### Color Scheme
- **Primary**: Blue gradients (blue-500 to cyan-500)
- **Background**: Light blue gradients (blue-50 to cyan-100)
- **Buttons**: Blue and cyan with proper contrast
- **Display**: Clean white/light blue with blue text

## 📁 Project Structure

```
src/
├── app/
│   ├── page.tsx          # Main calculator component
│   ├── layout.tsx        # Root layout with metadata
│   └── globals.css       # Global styles
├── components/
│   └── ui/               # shadcn/ui components
├── hooks/
│   └── use-toast.ts      # Toast notifications
└── lib/
    ├── utils.ts          # Utility functions
    ├── db.ts             # Database configuration
    └── socket.ts         # WebSocket support
```

## 🚀 Deployment

The calculator is ready for deployment to any platform that supports Next.js:

### Vercel (Recommended)
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

### Netlify
```bash
# Build the project
npm run build

# Deploy the out folder to Netlify
```

### Other Platforms
- **GitHub Pages**: Use `next export` for static export
- **AWS Amplify**: Connect your GitHub repository
- **Railway**: Deploy with one click

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🌟 Show Your Support

Give a ⭐️ if this project helped you!

---

Built with ❤️ for the calculator community. Featuring modern web technologies and beautiful design.
